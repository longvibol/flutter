<?php
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Route;
use App\Models\Product;
use App\Http\Controllers\ProductController;



Route::get('/home',function(){
    //return 
    return view('home');
});

Route::get('data',function(){
    return response()->json([
        'name'=> 'dara',
        'age'=> '20'
    ]);
});

Route::get('user/{id}',function($id){
    return $id;
});



Route::get('student/{id?}',function(?string $id = null){
    return $id;
});


Route::get('students',function(){
    $students = DB::table('students')->get();
    return response()->json($students);
});

Route::get('inser-new-student',function(){
    for($i =0;$i<100;$i++){
        DB::table('students')->insert([
            'fullname' => 'Vuthy',
            'age' => 20,
            'phone'=>"02345678",
            "bio"=> "student at university"
        ]);
    }
    return response()->json([
        'message'=> 'students created'
    ]);
});

Route::get('update-student/{id}',function($id){
    $affected = DB::table('students')
              ->where('id', $id)
              ->update([
                'fullname'=> "Sokha",
                "age"=> 22,
                "bio"=> "Teacher"
              ]);

            if($affected == 1){
                return response()->json([
                    'message'=> 'students updated'
                ]);
            }
            else{
                return response()->json([
                    'message'=> 'no row effected'
                ]);
            }
});

Route::get('delete-student/{id}',function($id){
 
$deleted = DB::table('students')->where('id','=', $id)->delete();
return response()->json(['message'=>"student deleted"]);
});


//ORM Section 

Route::get('products',[ProductController::class,'index']);
