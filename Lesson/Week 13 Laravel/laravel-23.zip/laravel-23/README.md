1.ចូរបង្កើត table students មួយដោយប្រើ Migration នៅក្នុង Laravel ហើយទាញទិន្នជា JSON ដើម្បីបង្ហាញពីពួកវានៅលើ Browser។



2. ចូរបង្កើត table (products) ដោយប្រើ Migration នៅក្នុង Laravel ហើយទាញទិន្នបង្ហានៅលើ Broswer ដោយប្រើ Blade Engine របស់ Laravel ជាមួយ ORM Eloquent ដើម្បីបង្ហាញពីពួកវានៅលើ Browser ជា Data Table។






```php
php artisan make:migration create_students_table
```
```php
php artisan migrate
```
```php